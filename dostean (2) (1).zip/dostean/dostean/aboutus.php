<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
WELCOME TO DOSTEAN

The Biscuit Cup Cafe

Known for its hot but mild chai which gives an exotic taste and it’s exquisite hot chocolate served in a crispy biscuit cup.

Namaste!
About Dostean
It is a surat based startup, initiated by 3 friends on 15th of September 2020.Their love for chai led them to start their own cafe franchise in Gujarat.We follow a very unique theme of serving tea/hot chocolate in biscuit cups.Our main motto has always been to provide a covenient spot for (adj)citizens of Gujarat to spend their quality hours together.The aura of the cafe is so rejuvenating. We organise birthday parties both for children as well as couples providing them with a romantic ambience.
We have been successful in running this cafe from the past couple of years.Our vision to make…

                                                   DOSTEA AUR 
                                              DOSTON KE SAATH
                                              Ye Din Bi Kya Din Hai

    
</body>
</html>